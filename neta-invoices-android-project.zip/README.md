# NeTA Invoices – Android app

Quotes and invoices with PDF export (logo included), WhatsApp and email sharing.

## Get the APK
1. Create a free account at github.com and make a **new repository** (private is fine).
2. Upload everything in this folder to it (keep the folder structure, including `.github/workflows`).
3. Open the **Actions** tab → **Build Android APK** → **Run workflow** (it also runs on every upload).
4. After about 5–8 minutes open the finished run and download **NeTA-Invoices-apk** from *Artifacts*. Unzip it to get `app-debug.apk`.
5. Send the APK to your phone, tap it, and allow "Install unknown apps" when asked.

To change the app, edit `www/index.html` and commit; a new APK is built automatically.
